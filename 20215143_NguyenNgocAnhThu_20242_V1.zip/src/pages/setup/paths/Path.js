export const Path = () => {
  return <div className="content"> </div>;
};
