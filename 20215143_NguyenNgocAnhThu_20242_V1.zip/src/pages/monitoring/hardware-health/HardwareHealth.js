export const HardwareHealth = () => {
  return <div className="content"></div>;
};
