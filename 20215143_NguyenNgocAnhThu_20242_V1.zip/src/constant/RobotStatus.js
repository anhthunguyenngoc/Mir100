export const Robot_State_Id = {
  READY: 3,
  PAUSE: 4,
  MANUAL_CONTROL: 11,
};
