export const PathGuide = () => {
  return <div className="content"> </div>;
};
