/**
 * Cập nhật priority của action trong mảng actions theo action_type.
 * @param {Block[]} actions - Mảng các action.
 * @param {string} actionType - action_type cần cập nhật.
 * @param {number} newPriority - Giá trị priority mới.
 * @returns {Block[]} - Mảng actions đã cập nhật.
 */
export function updateActionPriorityInList(actions, actionType, newPriority) {
  return actions.map((action) => {
    if (action.action_type === actionType) {
      return { ...action, priority: newPriority };
    }
    return action;
  });
}

/**
 * Cập nhật giá trị parameter trong action theo action_type và parameter_id.
 * @param {Block[]} actions - Mảng actions.
 * @param {string} uniqueId - uniqueId của action cần sửa.
 * @param {string} parameterId - ID của parameter cần sửa.
 * @param {string|number|boolean} newValue - Giá trị mới.
 * @returns {Block[]} - Mảng actions đã cập nhật.
 */
export function updateParameterValueInList(
  actions,
  uniqueId,
  parameterId,
  newValue
) {
  return actions.map((action) => {
    if (action.uniqueId === uniqueId) {
      const updatedParams = action.parameters.map((param) =>
        param.id === parameterId ? { ...param, value: newValue } : param
      );
      return { ...action, parameters: updatedParams };
    }
    return action;
  });
}

export function updateSubTaskParameterValueInList(
  actions,
  uniqueId,
  subTaskUniqueId,
  scopeParamId,
  parameterId,
  newValue
) {
  return actions.map((action) => {
    if (action.uniqueId !== uniqueId) return action;

    const updatedSubTasks = {
      ...action.subTasks,
      [scopeParamId]: (action.subTasks?.[scopeParamId] || []).map((subTask) => {
        if (subTask.uniqueId !== subTaskUniqueId) return subTask;

        const updatedParams = subTask.parameters.map((param) =>
          param.id === parameterId ? { ...param, value: newValue } : param
        );

        return { ...subTask, parameters: updatedParams };
      }),
    };

    return { ...action, subTasks: updatedSubTasks };
  });
}

/**
 * Cập nhật cả priority và parameter.value của action theo action_type.
 * @param {Block[]} actions - Mảng actions.
 * @param {string} actionType - action_type của action.
 * @param {string} parameterId - ID của parameter.
 * @param {string|number|boolean} newValue - Giá trị mới cho parameter.
 * @param {number} newPriority - Giá trị priority mới.
 * @returns {Block[]} - Mảng actions đã cập nhật.
 */
export function updatePriorityAndParameterInList(
  actions,
  actionType,
  parameterId,
  newValue,
  newPriority
) {
  return actions.map((action) => {
    if (action.action_type === actionType) {
      const updatedParams = action.parameters.map((param) =>
        param.id === parameterId ? { ...param, value: newValue } : param
      );
      return {
        ...action,
        priority: newPriority,
        parameters: updatedParams,
      };
    }
    return action;
  });
}

export function updateTaskOrSubTaskProps(
  actions,
  taskId, // ID của task cha
  scopeParamId, // Nếu là subtask thì cần truyền scopeParamId
  subTaskId, // Nếu là subtask thì cần truyền subTaskId
  propsValue
) {
  return actions.map((task) => {
    if (task.uniqueId !== taskId) return task;

    // Cập nhật trực tiếp task nếu không có subTaskId
    if (!subTaskId) {
      return {
        ...task,
        ...propsValue,
      };
    }

    // Cập nhật subtask bên trong scopeParam
    const updatedSubTasks = {
      ...task.subTasks,
      [scopeParamId]: (task.subTasks?.[scopeParamId] || []).map((subTask) =>
        subTask.uniqueId === subTaskId ? { ...subTask, ...propsValue } : subTask
      ),
    };

    return {
      ...task,
      subTasks: updatedSubTasks,
    };
  });
}

// Hàm tìm parameter config từ options
export const getParameterConfig = (options, paramId) => {
  return options.find((opt) => opt.id === paramId);
};

// Hàm kiểm tra điều kiện trong descriptions
export const checkConditions = (descConditions, conditionValues) => {
  if (!descConditions || descConditions.length === 0) return true;

  return descConditions.every((cond) => {
    const paramValue = conditionValues[cond.parameter_id];
    switch (cond.operator) {
      case '==':
        return paramValue === cond.value;
      case '!=':
        return paramValue !== cond.value;
      case '>':
        return paramValue > cond.value;
      case '>=':
        return paramValue >= cond.value;
      case '<':
        return paramValue < cond.value;
      case '<=':
        return paramValue <= cond.value;
      default:
        return false;
    }
  });
};

// Hàm lấy description phù hợp
const getApplicableDescription = (
  conditionValues,
  descriptions,
  description
) => {
  // Tìm description có điều kiện thỏa mãn
  for (const desc of descriptions) {
    if (checkConditions(desc.conditions, conditionValues)) {
      return desc;
    }
  }

  return description ? { text: description, conditions: [] } : descriptions[0];
};

// Hàm parse description text để lấy danh sách tham số cần thiết
export const getParameters = (applicableDesc) => {
  // Tìm tất cả các placeholder %(...) trong text
  const paramMatches = applicableDesc.text.match(/%\(([^)]+)\)/g);

  if (!paramMatches) {
    return [];
  }

  // Extract parameter names từ matches
  const paramNames = paramMatches.map((match) => {
    const paramName = match.replace(/^%\(/, '').replace(/\)[sdf]?$/, '');
    return paramName;
  });

  // Loại bỏ duplicate
  return [...new Set(paramNames)];
};

// Hàm parse description text để lấy danh sách tham số cần thiết
export const getRequiredParameters = (condition, descriptions, description) => {
  const applicableDesc = getApplicableDescription(
    condition.values,
    descriptions,
    description
  );

  if (!applicableDesc || !applicableDesc.text) {
    return [];
  }

  return getParameters(applicableDesc);
};

export const initConditions = (parameters, description, descriptions) => {
  const des = description ? { text: description } : descriptions[0];

  const requiredParams = getParameters(des);

  return requiredParams.map((item) => {
    const param = parameters.find((i) => i.id == item);
    return {
      id: item,
      ...param,
    };
  });
};

export const getParamDefault = (parameters, des, newValue) => {
  const requiredParams = getParameters(des);

  return requiredParams.map((item) => {
    const param = parameters.find((i) => i.id == item);

    return {
      id: item,
      ...(param.id === "compare" ? {...param, value: newValue} : param),
    };
  });
};

export const findActionByType = (targetType, allActions) => {
  for (const group of allActions) {
    const match = group.actions.find(
      (action) => action.action_type === targetType
    );
    if (match) {
      return match;
    }
  }
  return null;
};

export const getActionsWithScope = (data) => {
  return data.actions.filter((action) =>
    action.parameters.some((param) => param.type === 'Scope')
  );
};

export function getScopeParams(actionData) {
  if (!actionData || !actionData.parameters) {
    return [];
  }

  return actionData.parameters.filter((param) => param.type === 'Scope');
}

export function enhanceParameters(actionParameters, actionTypeParameters) {
  if (!actionParameters || !actionTypeParameters) {
    return actionParameters || [];
  }

  return actionParameters.map((param) => {
    // Tìm thông tin từ actionType dựa trên id hoặc name
    const typeParam = actionTypeParameters.find(
      (tp) => tp.id === param.id || tp.name === param.name
    );

    return {
      ...param,
      name: typeParam?.name || param.name,
      help: typeParam?.help || param.help || '',
    };
  });
}

export const calculateTaskPriorities = (tasks) => {
  let currentPriority = 1;

  const assignPriority = (taskList) => {
    return taskList.map((task) => {
      // Gán priority cho task hiện tại
      const updatedTask = { ...task, priority: currentPriority++ };

      // Nếu task có scope parameters và subtasks
      const scopeParams = getScopeParams(task);
      if (scopeParams && scopeParams.length > 0) {
        // Đảm bảo subtasks là object
        updatedTask.subtasks = { ...(task.subtasks || {}) };

        scopeParams.forEach((scopeParam) => {
          const subtasks = task.subtasks?.[scopeParam.id] || [];
          if (Array.isArray(subtasks) && subtasks.length > 0) {
            // Gán lại các subtasks đã cập nhật priority
            updatedTask.subtasks[scopeParam.id] = assignPriority(subtasks);
          }
        });
      }

      return updatedTask;
    });
  };

  return assignPriority(tasks);
};

// Hàm helper để lấy tất cả tasks theo thứ tự priority (flatten)
export const getAllTasksFlattened = (tasks) => {
  const result = [];

  const flattenTask = (task) => {
    result.push(task);

    const scopeParams = getScopeParams(task);
    if (scopeParams && scopeParams.length > 0) {
      scopeParams.forEach((scopeParam) => {
        const subtasks = task.subtasks?.[scopeParam.id] || [];
        subtasks.forEach((subtask) => {
          flattenTask(subtask);
        });
      });
    }
  };

  tasks.forEach(flattenTask);
  return result;
};

// Hàm để log tất cả tasks với priority (for debugging)
export const logTasksWithPriorities = (tasks) => {
  const flatTasks = getAllTasksFlattened(tasks);
  console.log('Tasks with priorities:');
  flatTasks.forEach((task) => {
    console.log(`Priority ${task.priority}: ${task.name} (${task.uniqueId})`);
  });
};

export const ConditionUtils = {
  /**
   * Tách điều kiện IF phức tạp
   */
  splitIfCondition(originalTask, conditions, logicalOperators) {
    const tasks = [];
    let currentTaskId = originalTask.uniqueId;

    // Tạo nested if conditions dựa trên toán tử logic
    for (let i = 0; i < conditions.length; i++) {
      const condition = conditions[i];
      const isLastCondition = i === conditions.length - 1;
      const operator = logicalOperators[i - 1]; // Toán tử trước condition này

      const newTask = {
        ...originalTask,
        uniqueId:
          i === 0
            ? originalTask.uniqueId
            : `${originalTask.uniqueId}_split_${i}`,
        priority: originalTask.priority, // Tăng priority nhẹ để giữ thứ tự
        parameters: this.createSingleConditionParameters(
          originalTask.parameters,
          condition
        ),
        conditionsData: {
          conditions: [condition],
          logicalOperators: [],
        },
        subtasks: i === 0 ? originalTask.subtasks : {}, // Chỉ task đầu tiên giữ subtasks
        originalTaskId: originalTask.uniqueId, // Để tracking
        splitIndex: i,
      };

      // Xử lý logic dựa trên toán tử
      if (i === 0) {
        // Task đầu tiên
        if (logicalOperators[0] === '&&') {
          // AND: nếu true thì tiếp tục check condition tiếp theo
          newTask.onTrueAction = 'continue';
          newTask.onFalseAction = 'exit'; // False thì thoát luôn
        } else if (logicalOperators[0] === '||') {
          // OR: nếu true thì thực hiện luôn, false thì check condition tiếp theo
          newTask.onTrueAction = 'execute';
          newTask.onFalseAction = 'continue';
        }
      } else if (isLastCondition) {
        // Task cuối cùng
        newTask.onTrueAction = 'execute';
        newTask.onFalseAction = 'exit';
      } else {
        // Task ở giữa
        if (logicalOperators[i] === '&&') {
          newTask.onTrueAction = 'continue';
          newTask.onFalseAction = 'exit';
        } else if (logicalOperators[i] === '||') {
          newTask.onTrueAction = 'execute';
          newTask.onFalseAction = 'continue';
        }
      }

      tasks.push(newTask);
    }

    return tasks;
  },

  splitComplexCondition(task, allTasks = []) {
    const { conditionsData } = task;

    if (!conditionsData) {
      return [task]; // Không có điều kiện phức tạp, trả về task gốc
    }

    const { conditions, logicalOperators } = conditionsData;

    let splitTasks = [];
    if (task.action_type === 'if') {
      splitTasks = this.splitIfCondition(task, conditions, logicalOperators);
    } else if (task.action_type === 'while') {
      splitTasks = this.splitWhileCondition(task, conditions, logicalOperators);
    } else {
      return [task];
    }

    // Cập nhật priority cho các tasks đã tách và toàn bộ danh sách
    // return this.updatePrioritiesAfterSplit(task, splitTasks, allTasks);
    return splitTasks;
  },

  /**
   * Cập nhật priority sau khi tách task
   * @param {Object} originalTask - Task gốc
   * @param {Array} splitTasks - Các tasks đã tách
   * @param {Array} allTasks - Danh sách tất cả tasks
   * @returns {Array} - Danh sách tasks với priority đã cập nhật
   */
  updatePrioritiesAfterSplit(originalTask, splitTasks, allTasks) {
    const originalPriority = originalTask.priority;
    const splitCount = splitTasks.length;

    // Tạo bản đồ priority mới
    const priorityMap = new Map();

    // 1. Gán priority cho các split tasks
    splitTasks.forEach((task, index) => {
      priorityMap.set(task.uniqueId, originalPriority + index);
    });

    // 2. Dịch chuyển priority của các tasks sau originalTask
    allTasks.forEach((task) => {
      if (task.uniqueId === originalTask.uniqueId) {
        // Skip task gốc vì sẽ bị thay thế
        return;
      }

      if (task.priority > originalPriority) {
        // Dịch chuyển các tasks có priority lớn hơn task gốc
        const newPriority = task.priority + (splitCount - 1);
        priorityMap.set(task.uniqueId, newPriority);
      } else {
        // Giữ nguyên priority cho các tasks trước task gốc
        priorityMap.set(task.uniqueId, task.priority);
      }
    });

    // 3. Áp dụng priority mới cho split tasks
    const updatedSplitTasks = splitTasks.map((task) => ({
      ...task,
      priority: priorityMap.get(task.uniqueId),
    }));

    // 4. Trả về kết quả để cập nhật toàn bộ danh sách tasks
    return updatedSplitTasks;
  },

  /**
   * Áp dụng priority map cho toàn bộ danh sách tasks
   * @param {Array} allTasks - Danh sách tất cả tasks
   * @param {Map} priorityMap - Bản đồ priority mới
   * @param {String} originalTaskId - ID của task gốc bị thay thế
   * @returns {Array} - Danh sách tasks đã cập nhật priority
   */
  applyPriorityUpdates(allTasks, priorityMap, originalTaskId) {
    return allTasks
      .filter((task) => task.uniqueId !== originalTaskId) // Loại bỏ task gốc
      .map((task) => ({
        ...task,
        priority: priorityMap.get(task.uniqueId) || task.priority,
      }));
  },

  /**
   * Tách điều kiện IF phức tạp thành một task với nested if conditions
   */
  splitIfCondition(originalTask, conditions, logicalOperators) {
    // Tạo task chính với condition đầu tiên
    const mainTask = {
      ...originalTask,
      parameters: this.createSingleConditionParameters(
        originalTask.parameters,
        conditions[0]
      ),
      conditionsData: {
        conditions: [conditions[0]],
        logicalOperators: [],
      },
      originalTaskId: originalTask.uniqueId,
      splitIndex: 0,
    };

    // Hàm đệ quy để tạo nested subtasks
    const createNestedSubtasks = (conditionIndex) => {
      const isLastCondition = conditionIndex === conditions.length - 1;

      if (isLastCondition) {
        // Condition cuối cùng: trả về subtasks gốc
        return { ...originalTask.subtasks };
      }

      const currentOperator = logicalOperators[conditionIndex];
      const nextCondition = conditions[conditionIndex + 1];

      // Tạo nested task cho condition tiếp theo
      const nestedTask = {
        ...originalTask,
        uniqueId: `${originalTask.uniqueId}_nested_${conditionIndex + 1}`,
        priority: originalTask.priority + conditionIndex + 1,
        parameters: this.createSingleConditionParameters(
          originalTask.parameters,
          nextCondition
        ),
        conditionsData: {
          conditions: [nextCondition],
          logicalOperators: [],
        },
        originalTaskId: originalTask.uniqueId,
        splitIndex: conditionIndex + 1,
        subtasks: createNestedSubtasks(conditionIndex + 1), // Đệ quy cho condition tiếp theo
      };

      if (currentOperator === '&&') {
        // AND: true → next condition, false → false branch của original
        return {
          true: [nestedTask],
          false: originalTask.subtasks?.false || [],
        };
      } else if (currentOperator === '||') {
        // OR: true → true branch của original, false → next condition
        return {
          true: originalTask.subtasks?.true || [],
          false: [nestedTask],
        };
      } else {
        // Default: AND logic
        return {
          true: [nestedTask],
          false: originalTask.subtasks?.false || [],
        };
      }
    };

    // Gán subtasks được tạo bằng đệ quy
    mainTask.subtasks = createNestedSubtasks(0);

    return [mainTask];
  },

  /**
   * Tách điều kiện WHILE phức tạp
   */
  splitWhileCondition(originalTask, conditions, logicalOperators) {
    const tasks = [];

    // Tạo một wrapper while chung
    const wrapperTask = {
      ...originalTask,
      uniqueId: `${originalTask.uniqueId}_wrapper`,
      priority: originalTask.priority, // Sẽ được cập nhật sau
      parameters: [],
      subtasks: {},
      isWrapper: true,
    };

    tasks.push(wrapperTask);

    // Tạo các condition checks bên trong wrapper
    for (let i = 0; i < conditions.length; i++) {
      const condition = conditions[i];
      const isLastCondition = i === conditions.length - 1;

      const conditionTask = {
        ...originalTask,
        action_type: 'if',
        uniqueId: `${originalTask.uniqueId}_check_${i}`,
        priority: originalTask.priority, // Sẽ được cập nhật sau
        parameters: this.createSingleConditionParameters(
          originalTask.parameters,
          condition
        ),
        conditionsData: {
          conditions: [condition],
          logicalOperators: [],
          hasComplexCondition: false,
        },
        subtasks: isLastCondition ? originalTask.subtasks : {},
        scope_reference: wrapperTask.uniqueId,
        originalTaskId: originalTask.uniqueId,
        splitIndex: i,
        isLastSplit: isLastCondition,
      };

      tasks.push(conditionTask);
    }

    return tasks;
  },

  /**
   * Thiết lập logic cho điều kiện
   */
  setupConditionLogic(task, index, isLastCondition, logicalOperators) {
    if (index === 0) {
      // Task đầu tiên
      if (logicalOperators[0] === '&&') {
        task.onTrueAction = 'continue';
        task.onFalseAction = 'exit';
      } else if (logicalOperators[0] === '||') {
        task.onTrueAction = 'execute';
        task.onFalseAction = 'continue';
      }
    } else if (isLastCondition) {
      // Task cuối cùng
      task.onTrueAction = 'execute';
      task.onFalseAction = 'exit';
    } else {
      // Task ở giữa
      if (logicalOperators[index] === '&&') {
        task.onTrueAction = 'continue';
        task.onFalseAction = 'exit';
      } else if (logicalOperators[index] === '||') {
        task.onTrueAction = 'execute';
        task.onFalseAction = 'continue';
      }
    }
  },

  /**
   * Tạo parameters cho single condition
   */
  createSingleConditionParameters(originalParameters, condition) {
    // Giữ nguyên tất cả parameters, chỉ cập nhật conditionsData
    // vì các parameters khác (compare, module, operator, value, etc.) vẫn cần thiết
    return originalParameters.map((param) => {
      // Giữ nguyên tất cả parameters
      return { ...param };
    });
  },

  /**
   * Xử lý toàn bộ danh sách tasks có điều kiện phức tạp
   */
  processComplexConditions(tasks) {
    const processedTasks = [];

    tasks.forEach((task) => {
      const splitTasks = this.splitComplexCondition(task, tasks);
      processedTasks.push(...splitTasks);
    });

    return processedTasks;
  },

  /**
   * Tính toán lại priority sau khi tách
   */
  recalculatePriorities(tasks) {
    return tasks.map((task, index) => ({
      ...task,
      priority: index + 1,
    }));
  },
};
