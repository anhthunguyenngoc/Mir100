export const SafetySystem = () => {
  return <div className="content"></div>;
};
